 <footer class="footer">
               <div class="container">
                  <!-- top footer statrs -->
                  <div class="row top-footer">
                     <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                        <a href="index.php" style="font-size:20px;"> Pasūtīt  </a><br /> <span>  </span>
                     </div>
                     <div class="col-xs-12 col-sm-2 about color-gray">
                        <h5>Par mums</h5>
                        <ul>
                           <li><a href="about-us.php">Par mums</a> </li>
                           <li><a href="contact.php">Sazinieties ar mums</a> </li>
                       
                        </ul>
                     </div>
                     <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>My Account</h5>
                        <ul>
                           <li><a href="profile.php">Mans profils</a> </li>
                           <li><a href="cart.php">Mans grozs</a> </li>
                           <li><a href="my-order.php">Mani pasūtījumi</a> </li>
                        
                        </ul>
                     </div>
        <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>Pasūtījumu izsekošana </h5>
                        <ul>
                           <li><a href="track-order-on.php">Sekot pēc pasūtījuma</a> </li>
                       
                        
                        </ul>
                     </div>

                
                <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>Admin </h5>
                        <ul>
                           <li><a href="admin" target="_blank">Login </a> </li>
                       
                        
                        </ul>
                     </div>
                
                
                  </div>
                  <!-- top footer ends -->
  
                  <!-- bottom footer ends -->
               </div>
            </footer>
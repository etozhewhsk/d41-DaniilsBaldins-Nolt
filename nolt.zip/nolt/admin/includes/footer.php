<div class="footer">
            
            <div>
                <strong></strong>
            </div>
        </div>
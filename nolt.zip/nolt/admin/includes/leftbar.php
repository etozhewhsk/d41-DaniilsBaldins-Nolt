    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <img alt="image" class="rounded-circle" src="img/user.png"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <?php
$admid=$_SESSION['fosaid'];
$ret=mysqli_query($con,"select AdminName from tbladmin where ID='$admid'");
$row=mysqli_fetch_array($ret);
$name=$row['AdminName'];

?>
                        
                            <span class="text-muted text-xs block"><?php echo $name; ?> <b class="caret"></b></span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a class="dropdown-item" href="adminprofile.php">Profils</a></li>
                            <li><a class="dropdown-item" href="changepassword.php">Mainit paroli</a></li>
                            <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Iziet</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        NOLT
                    </div>
                </li>
                <li>
                    <a href="dashboard.php"><i class="fa fa-th-large"></i> <span class="nav-label">Statistika</span> <span class="fa arrow"></span></a>
                                    </li>
                                    <li>
                    <a href="user-detail.php"><i class="fa fa-users"></i> <span class="nav-label">Reģistrēti lietotāji</span> <span class="fa arrow"></span></a>
                                    </li>
                
              
               
              
                <li>
                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Kategorijas</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="add-foodcategory.php">Kategorijas</a></li>
                        <li><a href="manage-foodcategory.php">Pārvaldīt kategoriju</a></li>
                    
                       
                    </ul>
                </li>
 <li>
                    <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Ēdienu izvēlne</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="add-fooditem.php">Pievienojiet ēdienu</a></li>
                        <li><a href="manage-fooditems.php">Pārvaldiet ēdienu</a></li>
                    
                       
                    </ul>
                </li>  
                <li>
                    <a href="#"><i class="fa fa-list"></i> <span class="nav-label">Pasūtījumi</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                         <li><a href="notconfirmedyet.php">Vēl nav apstiprināts</a></li>
                        <li><a href="confirmed-order.php">Pasūtījums apstiprināts</a></li>
                        <li><a href="foodbeingprepared.php">Tiek gatavoti ēdieni</a></li>
                        <li><a href="food-pickup.php">Gatavs saņemšanai</a></li>
                        <li><a href="food-delivered.php">Ēdiens piegādāts</a></li>
                        <li><a href="canclled-order.php">Atcelts</a></li>
                         <li><a href="all-order.php">Visi pasūtījumi</a></li>
                    
                       
                    </ul>
                </li>
                   <li>
                    <a href="#"><i class="fa fa-file"></i> <span class="nav-label">Atskaites</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                         <li><a href="bwdates-report-ds.php">-</a></li>
                        <li><a href="requestcount-report-ds.php">-</a></li>
                        <li><a href="sales-reports.php">-</a></li>
                       
                    </ul>
                </li>
                <li>
                    <a href="search.php"><i class="fa fa-th-large"></i> <span class="nav-label">Meklēt</span> <span class="fa arrow"></span></a>
                                    </li>
                                    <li>
               
            </ul>

        </div>
    </nav>